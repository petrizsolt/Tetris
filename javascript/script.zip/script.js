let tetrisTable = []; // 10 sz�les, 20 magas t�mb

class Table {
    constructor(table) {
        this.table = table;
    }
    
    init() {
        //felt�lti 0 �rt�kekkel a k�tdimenzi�s t�mb�t
        let html = '<img src="img/default.png">';
        let element = document.getElementById('tab0');
        let ID = 0;
        
        for(let i = 0; i < 20; i++) {
            tetrisTable.push([]);
            for(let j = 0; j < 10; j++) {
                tetrisTable[i].push(0);
                element.insertAdjacentHTML('beforeend', '<img src="img/default.png", id = '+ [i,j]+' >');
                ID++;
            }
            element.insertAdjacentHTML('beforeend', '<br>');
        }
    }
    checkFullLine() {
        let fullIndex = [];
        for(let i = 0; i < 20; i++) {
            const someIsNotOne = tetrisTable[i].some(item => item !== 1);
            const isAllOne = !someIsNotOne; // <= this is your result
            
            if(isAllOne) {
                fullIndex.push(i);

            }
            
        }
        return fullIndex;
    }
    
    clearLines(ind) {
        function moveDown(start) {
            let until = ind[0];
            
            for(let i = start -1; i >= 0 ; i--) {
                for(let j = 0; j < tetrisTable[i].length; j++){
                    if(tetrisTable[i][j] === 1) {
                        tetrisTable[i][j] = 0;
                        tetrisTable[i+1][j] = 1;


                    }
                }
            }
            table.displayTable();
            
        }
        
        
        
        ind.forEach(cur => {
            for(let i = 0; i < tetrisTable[cur].length; i++) {
                tetrisTable[cur][i] = 0;
                
            }
            
            console.log('DOWN');
            moveDown(cur);
        });
            
        let until = ind[0];
        console.log(until);
        console.log( tetrisTable[until]   );
        //this.displayTable();
        /*
        for(let i = until -1; i >= 0 ; i--) {
            for(let j = 0; j < tetrisTable[i].length; j++){
                if(tetrisTable[i][j] === 1) {
                    tetrisTable[i][j] = 0;
                    tetrisTable[i+1][j] = 1;
                    
                    
                }
            }
        }*/
        this.displayTable();    
        
        
    }
    
    newRandomElement(allobj) {
        let fullIndexes = this.checkFullLine();
        fullIndexes.sort();
        this.clearLines(fullIndexes);
        
        
        console.log(fullIndexes);
        
        
        
        let rand = Math.floor(Math.random() * 2);
        allobj[rand].init();
        elementType = rand;
        
    }
    
    displayTable() {
        let html = '<img src="img/default.png">';
        
        for(let i = 0; i < 20; i++) {
            for(let j = 0; j < 10; j++) {
                let element = document.getElementById([i,j]);
                if(this.table[i][j] === 0) {
                    element.src = 'img/default.png';
                } else {
                    element.src = 'img/element.png';
                }
                
            }
        }

    }
}

class Element {
    // position: 0 = top, 1 = right, 2 = left, 3 = down
    constructor() {
        this.i = 0;
        this.j = 3;
        this.position = 0;
        //this.posItem = ['top', 'right','left','down'];
        this.timer = 300;
    }
    
    initElement() {
        this.i = 0;
        this.j = 3;
        this.position = 0;

;
    }    
}

class LineElement extends Element {
    constructor(i,j,position) {
        super(i,j,position);
        this.posItem = ['top','left'];
        
    }
    
    init() {
        this.initElement();
        tetrisTable[this.i][this.j] = 1;
        tetrisTable[this.i+1][this.j] = 1;
        tetrisTable[this.i+2][this.j] = 1;
        tetrisTable[this.i+3][this.j] = 1;
        this.repInterval = setInterval( () => {
            line.moveDown();
            table.displayTable();
            
            } , this.timer);
    }
    
    checkDown() {
        switch(this.position) {
            case 0: 
                return tetrisTable[this.i + 4 ][this.j] === 1;
            case 1: 
                return tetrisTable[this.i + 1 ][this.j] === 1 ||
                    tetrisTable[this.i + 1 ][this.j+1] === 1  ||
                    tetrisTable[this.i + 1 ][this.j+2] === 1  ||
                    tetrisTable[this.i + 1 ][this.j+3] === 1;
                
        }    
        
    }
    
    moveDown() {
        if(this.posItem[this.position] === 'top') {
            // f�gg�leges elemet lejebb viszi a t�mbbe 1-el.
            if( this.i >= 19-3 || this.checkDown()) {
                clearInterval(this.repInterval);
                if(tetrisTable[0][this.j] === 1) alert('END');
                    table.newRandomElement(allElements);
                
                return;
            }
                
            tetrisTable[this.i][this.j] = 0;
            tetrisTable[this.i+1][this.j] = 1;
            tetrisTable[this.i+2][this.j] = 1;
            tetrisTable[this.i+3][this.j] = 1;
            tetrisTable[this.i+4][this.j] = 1;


        }else if(this.posItem[this.position] === 'left') {
            if( this.i >= 19 || this.checkDown() ) {
                clearInterval(this.repInterval);
                if(tetrisTable[0][this.j] === 1) alert('END');
                table.newRandomElement(allElements);
                return;
            }
            tetrisTable[this.i][this.j] = 0;
            tetrisTable[this.i][this.j+1] = 0;
            tetrisTable[this.i][this.j+2] = 0;
            tetrisTable[this.i][this.j+3] = 0;
            // 1 sorral lejebb viszi a vizszintes elemet
            tetrisTable[this.i+1][this.j] = 1;
            tetrisTable[this.i+1][this.j+1] = 1;
            tetrisTable[this.i+1][this.j+2] = 1;
            tetrisTable[this.i+1][this.j+3] = 1;
                
        }
        
        
        this.i += 1;
        

    }
    moveRight() {
        //Ha az elem fuggolegesen all �s csak ha a palyan bel�l van
        if(this.posItem[this.position] === 'top' && this.j <= 8) {
            if(tetrisTable[this.i][this.j+1] == 1 || tetrisTable[this.i+1][this.j+1] == 1 ||
             tetrisTable[this.i+2][this.j+1] == 1 || tetrisTable[this.i+3][this.j+1] == 1 )
                return;
            tetrisTable[this.i][this.j] = 0;
            tetrisTable[this.i+1][this.j] = 0;
            tetrisTable[this.i+2][this.j] = 0;
            tetrisTable[this.i+3][this.j] = 0;
            // minden helyet a line elementnek jobbra tolja egyel
            tetrisTable[this.i][this.j+1] = 1;
            tetrisTable[this.i+1][this.j+1] = 1;
            tetrisTable[this.i+2][this.j+1] = 1; 
            tetrisTable[this.i+3][this.j+1] = 1;
            this.j +=1;
            
        } else if(this.posItem[this.position] === 'left' && this.j < 8-2) {
            if(tetrisTable[this.i][this.j+4] == 1 )
                return;
            
            tetrisTable[this.i][this.j] = 0;
            // elmozgatja a vonal elemet jobbra ha vizszintes allasba van
            tetrisTable[this.i][this.j+1] = 1;
            tetrisTable[this.i][this.j+2] = 1; 
            tetrisTable[this.i][this.j+3] = 1;
            tetrisTable[this.i][this.j+4] = 1;
            this.j +=1;
            
        }
        
        
        
    }
    moveLeft() {
        //Ha az elem fuggolegesen all �s csak ha a palyan bel�l van
        if(this.posItem[this.position] === 'top' && this.j > 0) {
            if(tetrisTable[this.i][this.j-1] == 1 || tetrisTable[this.i+1][this.j-1] == 1 ||
            tetrisTable[this.i+2][this.j-1] == 1 || tetrisTable[this.i+3][this.j-1] == 1 )
                return;
            tetrisTable[this.i][this.j] = 0;
            tetrisTable[this.i+1][this.j] = 0;
            tetrisTable[this.i+2][this.j] = 0;
            tetrisTable[this.i+3][this.j] = 0;
            // minden helyet a line elementnek jobbra tolja egyel
            tetrisTable[this.i][this.j-1] = 1;
            tetrisTable[this.i+1][this.j-1] = 1;
            tetrisTable[this.i+2][this.j-1] = 1; 
            tetrisTable[this.i+3][this.j-1] = 1;
            this.j -=1;
            
        } else if(this.posItem[this.position] === 'left' && this.j > 0) {
            if(tetrisTable[this.i][this.j-1] == 1 )
                return;
            tetrisTable[this.i][this.j+3] = 0;
            tetrisTable[this.i][this.j-1] = 1;
            this.j -=1;
            
        }
        
        
        
    }
    
    
    turnLeft() {
            // alulr�l kit�rli az elemet, felk�sziti a forgat�sra
            // csak akkor forgatja el ha forgat�s ut�n nem megy ki a palyarol
            if(this.j <= 8-2) {
                tetrisTable[this.i][this.j] = 1;
                tetrisTable[this.i+1][this.j] = 0;
                tetrisTable[this.i+2][this.j] = 0;
                tetrisTable[this.i+3][this.j] = 0;
                tetrisTable[this.i+4][this.j] = 0;
                // jobb oldalra felt�lti 1-esekkel a t�mb�t
                tetrisTable[this.i][this.j+1] = 1;
                tetrisTable[this.i][this.j+2] = 1;
                tetrisTable[this.i][this.j+3] = 1;
                this.position = 1; // �tv�ltja a cs�k helyzet�t forgat�sra
            //table.displayTable(); // frissiti az UI-t
            }
    }
    
    turnBack() {
            tetrisTable[this.i][this.j+1] = 0;
            tetrisTable[this.i][this.j+2] = 0;
            tetrisTable[this.i][this.j+3] = 0;
        
            tetrisTable[this.i+1][this.j] = 1;
            tetrisTable[this.i+2][this.j] = 1;
            tetrisTable[this.i+3][this.j] = 1;
            //table.displayTable();
            this.position = 0;
    }
    
}

class SquareElement extends Element {
    constructor(i,j,position) {
        super(i,j,position);
    }
    
    init() {
        this.initElement();
        tetrisTable[this.i][this.j] = 1;
        tetrisTable[this.i+1][this.j] = 1;
        tetrisTable[this.i][this.j+1] = 1;
        tetrisTable[this.i+1][this.j+1] = 1;
        
        this.repInterval = setInterval( () => {
            this.moveDown();
            table.displayTable();
            
            } , this.timer);
    }
    
    moveDown() {
        if( this.i >= 18 || tetrisTable[this.i +2][this.j] === 1 || 
           tetrisTable[this.i+2][this.j +1] === 1 ) {
            
            clearInterval(this.repInterval);
            if(tetrisTable[0][this.j] === 1) alert('END');
                table.newRandomElement(allElements);
                
            return;
         }
                
        tetrisTable[this.i][this.j] = 0;
        tetrisTable[this.i][this.j+1] = 0;
        
        tetrisTable[this.i+2][this.j] = 1;
        tetrisTable[this.i+2][this.j+1] = 1;
        this.i ++;

    }
    moveRight() {
        if( this.j <= 7 ) {
            if(tetrisTable[this.i][this.j+2] == 1 || tetrisTable[this.i+1][this.j+2] == 1)
                return;
            
            tetrisTable[this.i][this.j] = 0;
            tetrisTable[this.i+1][this.j] = 0;
            
            tetrisTable[this.i][this.j+2] = 1;
            tetrisTable[this.i+1][this.j+2] = 1;
            this.j +=1;
        
        }
    }
    moveLeft() {
        if(this.j > 0) {
            if(tetrisTable[this.i][this.j-1] == 1 || tetrisTable[this.i+1][this.j-1] == 1)
                return;
            tetrisTable[this.i][this.j+1] = 0;
            tetrisTable[this.i+1][this.j+1] = 0;
            
            tetrisTable[this.i][this.j-1] = 1;
            tetrisTable[this.i+1][this.j-1] = 1;
            
            this.j -=1;
            
        }
    }
    
}

let elementType, table, line;
elementType = 0; // 0 = line, 1 = square
table = new Table(tetrisTable);
table.init();

line = new LineElement();
square = new SquareElement();
let allElements = [line,square];


line.init();

table.displayTable();



function logKey(e){    
    switch(elementType) {
        case 0: 
            if (e.keyCode === 32) {
                if(line.position === 0)
                    line.turnLeft();
                else if(line.position === 1)
                    line.turnBack();

                table.displayTable();
            }
            else if(e.keyCode === 39) {
                line.moveRight();
                table.displayTable();
                
            }
            else if(e.keyCode === 37) {
                line.moveLeft();
                table.displayTable();
            }
            
            else if(e.keyCode === 40) {
                line.moveDown();
                table.displayTable();
            }break;
            
        case 1 :
            if(e.keyCode === 39) {
                square.moveRight();
                table.displayTable();
            }
            else if(e.keyCode === 37) {
                square.moveLeft();
                table.displayTable();
            }
            else if(e.keyCode === 40) {
                square.moveDown();
                table.displayTable();
            }break;
    }
    
}

//document.addEventListener('keypress', logKey);
document.addEventListener('keydown', logKey);
document.getElementById('btn-stop').addEventListener('click', () => {
     clearInterval(allElements[elementType].repInterval);
    
    
});

document.getElementById('btn-new').addEventListener('click', () => {
    location.reload();
    
    
});
